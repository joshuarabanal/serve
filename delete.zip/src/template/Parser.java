/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package template;

import java.io.File;

/**
 *
 * @author Joshua
 */
public class Parser {
    private File root;
    public Parser(File outputDir){
        root = outputDir;
    }
    
    public void parse(File html, File template){
        
    }
    
}
